/**
 * 
 */
package com.oirs.dao;

import com.oirs.bean.UserBean;
import com.oirs.exception.OIRSException;

/**
 * @author gowthc
 *
 */
public interface IOnlineInternalRecDAO {
	public abstract UserBean loginUser(String userName,String userPassword) throws OIRSException;
	public abstract boolean validatingUser(String Id, String password);
}
