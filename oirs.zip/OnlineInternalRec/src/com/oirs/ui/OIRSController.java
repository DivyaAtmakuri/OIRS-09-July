package com.oirs.ui;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.oirs.bean.EmployeeBean;
import com.oirs.bean.ProjectBean;
import com.oirs.bean.RequisitionBean;
import com.oirs.bean.UserBean;
import com.oirs.dao.RMGEDAOImpl;
import com.oirs.exception.OIRSException;
import com.oirs.service.AdminService;
import com.oirs.service.AuthenticateServiceImpl;
import com.oirs.service.IAdminService;
import com.oirs.service.IAuthenticateService;
import com.oirs.service.IRMGEService;
import com.oirs.service.IRMService;
import com.oirs.service.RMGEServiceImpl;
import com.oirs.service.RMServiceImpl;
import com.sun.xml.internal.ws.api.server.InstanceResolverAnnotation;

/**
 * Servlet implementation class OIRSController
 */
@WebServlet("/OIRSController")
public class OIRSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	public OIRSController() {
		super();
		// TODO Auto-generated constructor stub
	}
	UserBean userbean;
	HttpSession session;
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String option = request.getParameter("action");
		if(option.equals("logout")){
			System.out.println(session.isNew());
			session.invalidate();
			response.sendRedirect("./login.html");
		}

	}




	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		
		IAdminService adminService = new AdminService();
		IRMGEService iRMGEService = new RMGEServiceImpl();
		String option = request.getParameter("action");
		int RMGEnumReq = 0; 
		if(option.equals("LogIn")){
			String UserId = request.getParameter("userId");
			String userPassword = request.getParameter("userPassword");
			IAuthenticateService authService = new AuthenticateServiceImpl();
			try {
				userbean = authService.loginUser(UserId, userPassword);
				if(userbean != null){
					response.setStatus(200);
					session = request.getSession(true);
					session.setMaxInactiveInterval(7);
					String beanRole = userbean.getUserRole();
					String date =  userbean.getLastLogin();
					session.setAttribute("userId", userbean.getUserId());
					session.setAttribute("UserBean", userbean);
					session.setAttribute("logindate", userbean.getLastLogin());
					System.out.println("Last login : "+date);
					if(beanRole.equals("admin")){
//						request.setAttribute("UserBean", userbean);
//						request.setAttribute("logindate", userbean.getLastLogin());
						getServletContext().getRequestDispatcher("/AdminPage.jsp").forward(request,response);
					}
					else if(beanRole.equals("rm")){
						//request.setAttribute("UserBean", userbean);
						getServletContext().getRequestDispatcher("/RmPage.jsp").forward(request,response);
					}
					else if(beanRole.equals("rmge"))
					{
						//request.setAttribute("UserBean", userbean);
						getServletContext().getRequestDispatcher("/RmgePage.jsp").forward(request,response);
					}
				}
				else
				{
					response.setStatus(401);
					//response.sendError(response.SC_UNAUTHORIZED, "Invalid User name/Password");
					request.setAttribute("error","Invalid user name/Password");
					getServletContext().getRequestDispatcher("/ErrorPage.jsp").forward(request,response);
				}
				//out.println("Invalid UserName or Password");	
			}catch (OIRSException e) {}


		}
		else if(option.equals("Add New User"))
		{
			getServletContext().getRequestDispatcher("/addUser.jsp").forward(request,response);
		}
		else if(option.equals("Assign Role"))
		{
			try {
				List<String> list = adminService.getUserIds();
				request.setAttribute("userIds", list);
				getServletContext().getRequestDispatcher("/assignRole.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

		}
		else if(option.equals("Delete User"))
		{
			List<String> list;
			try {
				list = adminService.getUserIds();
				request.setAttribute("userIds", list);
				getServletContext().getRequestDispatcher("/DeleteUser.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		else if(option.equals("Adding New User"))
		{
			String newUserId = request.getParameter("newUserId");
			String newpswd = request.getParameter("newPwd");
			String newRole = request.getParameter("userRole").toLowerCase();
			String newHint = request.getParameter("userHint").toLowerCase();
			UserBean addUserBean = new UserBean();
			addUserBean.setUserId(newUserId);
			addUserBean.setUserPassword(newpswd);
			addUserBean.setUserRole(newRole);
			addUserBean.setHint(newHint);
			try {
				if(adminService.addNewUser(addUserBean).equals(null)){
					out.println("Details Not Inserted");
				}
				else{
					out.println("Data inserted succesfully");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Assigning"))
		{
			String assignUserId = request.getParameter("assignId");
			String assignRole = request.getParameter("assignRole");
			//userbean.setUserId(assignUserId);
			//userbean.setUserRole(assignRole);
			try {
				String res = adminService.assignRole(assignUserId, assignRole);
				if(res==null){
					out.println("User not found!!! Enter the valid user ID");
				}
				else
				{
					out.println("succesfully assigned role");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Delete"))
		{
			String deleteUserId = request.getParameter("deleteUserId");
			//userbean.setUserId(deleteUserId);
			try {
				String res = adminService.deleteUser(deleteUserId);
				if(res==null){
					out.print("User not found!!! Enter the valid user ID");
				}
				else{
					out.print("Deleted successfully");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("RaiseRequisitions"))
		{
			RequisitionBean reqBean = new RequisitionBean();
			String rmId = userbean.getUserId();//(String) session.getAttribute("userId"); //
			System.out.println("RaiseReq -->"+rmId);
			IRMService rmService = new RMServiceImpl();
			reqBean.setReqRmId(rmId);
			try {
				List<ProjectBean> prjBeanList = rmService.getProjectDetailsByStatus(rmId, "OPEN");
				for(ProjectBean prj : prjBeanList)
				{
					System.out.println(prj.getProjectId()+"\t"+prj.getProjectName());
				}
				request.setAttribute("projectDetails", prjBeanList);
				getServletContext().getRequestDispatcher("/RaiseRequisition.jsp").forward(request,response);
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Raise Requisition")){
			
			RequisitionBean reqBean = new RequisitionBean();
			IRMService rmService = new RMServiceImpl();
			//			ProjectBean projBean = new ProjectBean();
			try {
			String rmId = userbean.getUserId();
			System.out.println(rmId);
			String projId = request.getParameter("projId");
			String skill = request.getParameter("skill").toLowerCase();
			String domain = request.getParameter("domain").toLowerCase();
			int numReq = Integer.parseInt(request.getParameter("number"));
			String vacancy = request.getParameter("vacancy");
			reqBean.setReqRmId(rmId);
			reqBean.setReqProjectId(projId);
			reqBean.setReqSkill(skill);
			reqBean.setReqDomain(domain);
			reqBean.setReqVacancyName(vacancy);
			reqBean.setReqNoReq(numReq);

			
				String reqId = rmService.raiseRequisition(reqBean);
				if(reqId==null)
				{
					out.println("Raise Requisition failed");
				}
				else{

					out.println("Requisition Raised Succesfully for Requisition Id "+reqId);

				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
				response.setStatus(500);
				//response.sendError(response.SC_UNAUTHORIZED, "Invalid User name/Password");
				request.setAttribute("error","Oops!!! something went wrong : "+e.getMessage());
				getServletContext().getRequestDispatcher("/ErrorPage.jsp").forward(request,response);
			}
			catch (Exception e) {
				System.out.println(e.getMessage());
				response.setStatus(500);
				//response.sendError(response.SC_UNAUTHORIZED, "Invalid User name/Password");
				request.setAttribute("error","Oops!!! something went wrong : "+e.getMessage());
				getServletContext().getRequestDispatcher("/ErrorPage.jsp").forward(request,response);
			}
		}
		else if(option.equals("Accept/Reject")){
			System.out.println(session.getAttribute("userId"));
			
			String rmId = userbean.getUserId();//(String) session.getAttribute("userId");
			try {
				List<RequisitionBean> reqDetails = iRMGEService.getRequisitionByRMId(rmId);
				session.setAttribute("reqDetails", reqDetails);
				getServletContext().getRequestDispatcher("/RMReqAcceptReject.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


		}
		else if(option.equals("View Requisition Response")){

			String reqId = request.getParameter("reqId");	
			session.setAttribute("reqId", reqId);
			IRMService rmService = new RMServiceImpl();
			try {
				RequisitionBean reqBean = iRMGEService.getRequisitionDetails(reqId);
				session.setAttribute("numReq", reqBean.getReqNoReq());
				session.setAttribute("numAssigned", reqBean.getNumAssigned());
				List<EmployeeBean> empList = rmService.viewRequestRes(reqId);
				request.setAttribute("selectStatus", true);
				session.setAttribute("empDetails", empList);
				getServletContext().getRequestDispatcher("/ViewRequisitionResponse.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}			
		}

		else if(option.equals("Accept Employee")){

			String empIds[] = request.getParameterValues("empIds");
			String reqId = (String) session.getAttribute("reqId");
			boolean result = false;
			IRMService rmService = new RMServiceImpl();
			if(empIds.length>0){
				try {
					for(String empId:empIds){
						System.out.println("Selected emp : "+empId);
						result = rmService.acceptRes(empId, reqId);
					}	
					request.setAttribute("selectStatus", true);
					List<EmployeeBean> empList;

					empList = rmService.viewRequestRes(reqId);
					session.setAttribute("empDetails", empList);
					session.setAttribute("result", result);
					out.print("Employee accepted successfully!!!");
					//getServletContext().getRequestDispatcher("/ViewRequisitionResponse.jsp").forward(request,response);
				} catch (OIRSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else{
				request.setAttribute("selectStatus", false);
				getServletContext().getRequestDispatcher("/ViewRequisitionResponse.jsp").forward(request,response);				
			}

		}

		else if(option.equals("Reject Employee")){
			String empIds[] = request.getParameterValues("empIds");
			String reqId = (String) session.getAttribute("reqId");
			boolean result = false;
			IRMService rmService = new RMServiceImpl();
			if(empIds.length>0){
				try {
					for(String empId:empIds){
						System.out.println("Selected emp : "+empId);
						result = rmService.rejectRes(empId, reqId);
					}	
					request.setAttribute("selectStatus", true);
					List<EmployeeBean> empList;

					empList = rmService.viewRequestRes(reqId);
					session.setAttribute("empDetails", empList);
					session.setAttribute("result", result);
					out.print("Employee rejected successfully!!!");
					//getServletContext().getRequestDispatcher("/ViewRequisitionResponse.jsp").forward(request,response);
				} catch (OIRSException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else{
				request.setAttribute("selectStatus", false);
				getServletContext().getRequestDispatcher("/ViewRequisitionResponse.jsp").forward(request,response);				
			}

		}


		else if(option.equals("Close/unassign")){
			RequisitionBean reqBean = new RequisitionBean();
			String rmId = (String) session.getAttribute("userId"); // userbean.getUserId();
			IRMService rmService = new RMServiceImpl();
			reqBean.setReqRmId(rmId);
			try {
				List<ProjectBean> prjBeanList = rmService.getProjectDetailsByStatus(rmId, "OPEN");
				for(ProjectBean prj : prjBeanList)
				{
					System.out.println(prj.getProjectId()+"\t"+prj.getProjectName());
				}
				request.setAttribute("projectDetails", prjBeanList);
				getServletContext().getRequestDispatcher("/closeUnasignProj.jsp").forward(request,response);
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}

		else if(option.equals("Close Project"))
		{
			String projId = request.getParameter("projId");
			IRMService rmService = new RMServiceImpl();
			try {
				boolean result = rmService.unassignByPrjId(projId);
				if(result == true){
					out.println("Project Closed Succesfully");
				}
				else{
					out.println("Failed Closing the project");
				}
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("Unassign Employee"))
		{
			IRMService rmService = new RMServiceImpl();
			String prjId = request.getParameter("projId");
			try {
				List<EmployeeBean> bean = rmService.getEmpDetailsByPrjId(prjId);
				request.setAttribute("empBean", bean);
				request.setAttribute("prjId", prjId);
				getServletContext().getRequestDispatcher("/RMUnassignByEmpID.jsp").forward(request, response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else if(option.equals("unassignEmployee")){
			IRMService rmService = new RMServiceImpl();
			String empId = request.getParameter("empId");
			try {
				boolean result = rmService.unassignProject(empId);
				String prjId =  (String) request.getAttribute("prjId");
				List<EmployeeBean> bean = rmService.getEmpDetailsByPrjId(prjId);
				request.setAttribute("empBean", bean);
				getServletContext().getRequestDispatcher("/RMUnassignByEmpID.jsp").forward(request, response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else if(option.equals("ViewAllRequisitions"))
		{
			List<RequisitionBean> reqBeanList;
			try {
				reqBeanList = iRMGEService.getAllRequisitions();
				for(RequisitionBean req : reqBeanList)
				{
					System.out.println(req.getReqId()+"\t"+req.getReqRmId());
				}
				session.setAttribute("reqDetails", reqBeanList);
				getServletContext().getRequestDispatcher("/allRequisitions.jsp").forward(request,response);
			} catch (OIRSException e) {
				System.out.println(e.getMessage());
			}
		}
		else if(option.equals("View Requisition details"))
		{
			String reqId = request.getParameter("reqId");
			session.setAttribute("reqId", reqId);
			try {
				RequisitionBean reqBean = iRMGEService.getRequisitionDetails(reqId);
				request.setAttribute("reqBean", reqBean);
				session.setAttribute("reqBean", reqBean);
				getServletContext().getRequestDispatcher("/ViewRequisitionDetails.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else if(option.equals("Search Employee"))
		{

			RequisitionBean reqBean = (RequisitionBean) session.getAttribute("reqBean");

			//System.out.println(request.getAttribute("reqBean"));
			System.out.println(reqBean.getReqId()+ "-------Search");
			System.out.println(reqBean.getReqSkill()+ "-------Search");
			System.out.println(session.getAttribute("reqId")+"-----Session reqId");

			try {
				List<EmployeeBean> empList = iRMGEService.searchEmployee(reqBean);
				//request.setAttribute("reqId", reqBean.getReqId());
				session.setAttribute("numReq", reqBean.getReqNoReq());
				session.setAttribute("numAssigned", reqBean.getNumAssigned());
				request.setAttribute("empList", empList);
				getServletContext().getRequestDispatcher("/searchEmployee.jsp").forward(request,response);

			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}
		else if(option.equals("View Employee Details")){
			String empId = request.getParameter("empId");
			String reqId = (String) session.getAttribute("reqId");

			System.out.println("Req id -->"+reqId);
			EmployeeBean empBean;
			try {
				empBean = iRMGEService.getEmployeeDetails(empId);
				request.setAttribute("empBean", empBean);
				//request.setAttribute("reqId", reqId);
				getServletContext().getRequestDispatcher("/DisplayEmployeeDetails.jsp").forward(request,response);
			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		else if(option.equals("Assign Employee")){
			String reqId = (String) session.getAttribute("reqId");
			System.out.println("req Id -->"+reqId);
			String empId = (String) session.getAttribute("empId");
			System.out.println("Assign req -->"+reqId);
			System.out.println("Assign emp -->"+empId);
			try {
				boolean result = iRMGEService.assignProject(empId, reqId);

				if(result){
					System.out.println(result +"Assigned!!");
					//int numAssigned = (int) session.getAttribute("numAssigned");
					//session.setAttribute("numAssigned", ++numAssigned);
					try {
						RequisitionBean reqBean = (RequisitionBean) session.getAttribute("reqBean");
						int numAssigned = reqBean.getNumAssigned()+1;
						reqBean = iRMGEService.updateReqNumberAssigned(reqId, numAssigned);
						session.setAttribute("reqBean", reqBean);
						List<EmployeeBean> empList = iRMGEService.searchEmployee(reqBean);
						//request.setAttribute("reqId", reqBean.getReqId());
						session.setAttribute("numReq", reqBean.getReqNoReq());
						session.setAttribute("numAssigned", reqBean.getNumAssigned());
						request.setAttribute("empList", empList);
						getServletContext().getRequestDispatcher("/searchEmployee.jsp").forward(request,response);

					} catch (OIRSException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

				}
				else
				{
					out.print("Failed to assign");
				}


			} catch (OIRSException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}


			//searchEmployee(reqBean);
		}

	}

}
