/**
 * 
 */
package com.oirs.service;

import com.oirs.bean.UserBean;
import com.oirs.exception.OIRSException;

/**
 * @author gowthc
 *
 */
public interface IOnlineInternalRecService {
	public abstract UserBean loginUser(String userName,String userPassword) throws OIRSException;
	public boolean isValidUserName(String Name);
	public boolean ValidateUser(String Id, String password);
}
