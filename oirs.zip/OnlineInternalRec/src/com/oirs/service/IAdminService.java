package com.oirs.service;

import java.util.List;

import com.oirs.bean.UserBean;
import com.oirs.exception.OIRSException;

public interface IAdminService {
	public String addNewUser(UserBean userBean) throws OIRSException;
	public String assignRole(String userId,String role) throws OIRSException;
	public String deleteUser(String userId) throws OIRSException;	
	public List<String> getUserIds() throws OIRSException;
	public void generateReport() throws OIRSException;
	public boolean isValidUserid(String uid);
	public boolean isValidPassword(String pwd);
}
